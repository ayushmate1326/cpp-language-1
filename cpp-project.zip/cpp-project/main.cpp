// Online C++ compiler (editor)
// Write and run C++ online using this editor.

#include <iostream>
using namespace std;

class student
{
    public:
    int rollno;
    string name;

    void display()
    {
        cout << "Roll Number: " << rollno << endl;
        cout << "Name:" << name << endl;
    }
};

int main()
{
    //creating object
    student s1;

    // Assigning values
    s1.rollno = 896;
    s1.name = "nidhi mate";

    // calling function
    s1.display();

    return 0;
}
